function  R_final= double_channel_enhancement( I_hazy, R)
[ H, W, D]= size( R);
[ R,~]= sepGlow( R, 500, zeros( H, W, D), R);
 R_curve= feature_nsst( I_hazy, R);
 R_edge= feature_edge( I_hazy, R_curve);
 R_saturation= feature_saturation( I_hazy, R_edge);
 R_final= R_saturation;
end
function  enhanced_R= feature_nsst( I_hazy, R)

 scale_level= 3;
 alpha= 2.5;


 I_hazy_hsv= rgb2hsv( I_hazy);
 R_hsv= rgb2hsv( R);
 V_hazy= im2double( I_hazy_hsv(:,:, 3));
 V_R= im2double( R_hsv(:,:, 3));
[ p, q]= size( V_hazy);
 V_hazy= imresize( V_hazy,[ 512, 512]);
 V_R= imresize( V_R,[ 512, 512]);


 shear_parameters. dcomp=[ 3, 3, 4, 4];
 shear_parameters. dsize=[ 8, 8, 16, 16];
 lpfilt= 'maxflat';


[ coeffs_hazy,~]= nsst_dec2( V_hazy, shear_parameters, lpfilt);
[ coeffs_R, shear_R]= nsst_dec2( V_R, shear_parameters, lpfilt);


 level= length( shear_parameters. dcomp);
for  s= max( 1, level- scale_level+ 1): level
 currentLevel= s+ 1;


 nDirections= 2^ shear_parameters. dcomp( s);

for  d= 1: nDirections

 coeff_hazy= coeffs_hazy{ currentLevel}(:,:, d);
 coeff_R= coeffs_R{ currentLevel}(:,:, d);


 enhanced_coeff= coeff_R+ alpha*( coeff_hazy- mean( coeff_hazy(:)));


 threshold= 0.05* mean( enhanced_coeff(:));
 enhanced_coeff= wthresh( enhanced_coeff, 's', abs( threshold));

 coeffs_R{ currentLevel}(:,:, d)= enhanced_coeff;
end
end


 enhanced_V= nsst_rec2( coeffs_R, shear_R, lpfilt);

 enhanced_V= imresize( enhanced_V,[ p, q]);
 R_hsv(:,:, 3)= im2double( enhanced_V);
 enhanced_R= hsv2rgb_custom( R_hsv);

end


function  adjusted_img= feature_saturation( I_hazy, R)
 num_clusters= 100;


[ h, w,~]= size( I_hazy);

 data= reshape( I_hazy,[], 3);


 opts= statset( 'MaxIter', 100, 'Display', 'off');
[ idx,~]= kmeans( data, num_clusters, 'Options', opts, 'Replicates', 1);
 cluster_map= reshape( idx, h, w);

 adjusted_img= R;


for  k= 1: num_clusters
 mask=( cluster_map== k);
 adjusted_img= nonlinear_sat_adjust( adjusted_img, mask, 3, 0.2);
end
 ad_hsv= rgb2hsv( adjusted_img);
 ad_hsv(:,:, 2)= guided_filter( min( I_hazy,[], 3), ad_hsv(:,:, 2), 3, 0.000001);
 adjusted_img= hsv2rgb_custom( ad_hsv);
end
function  output= nonlinear_sat_adjust( img, mask, a, k)
 hsv= rgb2hsv( img);
 s= hsv(:,:, 2);


 region_s= s( mask);
if  isempty( region_s)
 output= img;
return ;
end
 S_mean= mean( region_s);


 low_sat_mask=( s< S_mean)& mask;
 delta_S= S_mean- s;


 adjustment= a* delta_S./( 1+ exp(- k* delta_S));
 adjustment= adjustment.* low_sat_mask;


 s_adjusted= s+ adjustment;
 s_adjusted= min( max( s_adjusted, 0), 1);


 output= hsv2rgb_custom( cat( 3, hsv(:,:, 1), s_adjusted, hsv(:,:, 3)));
end

function  R_edge= feature_edge( I_hazy, R)
 I_v= max( I_hazy,[], 3);


 I_sharp_v= max(( double( SSIF( I_hazy, I_hazy, 11, 0.01, 7.5, 1))),[], 3);

 I_sharp= log( I_sharp_v+ 1);
 I_smooth= double( guided_filter( log( I_v+ 1), log( I_v+ 1), 3, 0.000001));
 I_texture= I_sharp- I_smooth;
 I_edge= guided_filter( I_smooth, I_texture, 3, 0.000001);

 R_hsv= rgb2hsv( R);
 R_v= R_hsv(:,:, 3);
 R_v_edge= R_v.* exp( I_edge);

 R_edge= hsv2rgb_custom( cat( 3, R_hsv(:,:, 1), R_hsv(:,:, 2), R_v_edge));







end

function  RGB= hsv2rgb_custom( HSV)








 H= HSV(:,:, 1)* 6;
 S= HSV(:,:, 2);
 V= HSV(:,:, 3);

 C= V.* S;
 m= V- C;


 R= zeros( size( H));
 G= zeros( size( H));
 B= zeros( size( H));


 idx= floor( H);
 f= H- idx;


 case0=( idx== 0| idx== 6);
 R( case0)= C( case0);
 G( case0)= C( case0).* f( case0);
 B( case0)= 0;

 case1=( idx== 1);
 R( case1)= C( case1).*( 1- f( case1));
 G( case1)= C( case1);
 B( case1)= 0;

 case2=( idx== 2);
 R( case2)= 0;
 G( case2)= C( case2);
 B( case2)= C( case2).* f( case2);

 case3=( idx== 3);
 R( case3)= 0;
 G( case3)= C( case3).*( 1- f( case3));
 B( case3)= C( case3);

 case4=( idx== 4);
 R( case4)= C( case4).* f( case4);
 G( case4)= 0;
 B( case4)= C( case4);

 case5=( idx== 5);
 R( case5)= C( case5);
 G( case5)= 0;
 B( case5)= C( case5).*( 1- f( case5));


 RGB= cat( 3, R+ m, G+ m, B+ m);


 RGB= max( min( RGB, 1), 0);
end