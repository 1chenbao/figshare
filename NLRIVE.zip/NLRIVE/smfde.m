function R_final = smfde(I_hazy, ablation_mode)

% =========================================================
% ablation_mode:
%
% 0 = Original SMFDE
% 1 = Feature normalization only
% 2 = Normalization + adaptive feature weighting
% 3 = Normalization + soft fusion
% 4 = Full proposed method
% 5 = Full method with fixed feature weights
%
% =========================================================

if nargin < 2
    ablation_mode = 4;
end


%% =========================================================
% Stage 1: Generate intermediate images
% ==========================================================

I = zeros(size(I_hazy,1), size(I_hazy,2), ...
          size(I_hazy,3), 12);

range = [0.2, 0.4, 0.6, 0.8, 1, ...
         1.2, 1.4, 1.6, 1.8, 2.0];

for i = 1:10

    gamma = range(i);

    for c = 1:3
        I(:,:,c,i) = I_hazy(:,:,c).^gamma;
    end

end


for i = 1:5

    out = dehaze_fast(I(:,:,:,i), 0.95, 5);

    I(:,:,:,i) = out;

end


for i = 6:10

    out = dehaze_fast(1-I(:,:,:,i), 0.95, 5);

    I(:,:,:,i) = 1-out;

end


%% =========================================================
% Stage 2: Multi-scale fusion
% ==========================================================

R = multi_scale_fusion(I, ablation_mode);


%% =========================================================
% Stage 3: Original double-channel enhancement
% ==========================================================

R_final = double_channel_enhancement(I_hazy, R);

end



% =========================================================
% Multi-scale fusion
% ==========================================================

function R = multi_scale_fusion(I, ablation_mode)

r = size(I,1);
c = size(I,2);
N = size(I,4);


%% =========================================================
% Eq. (3): Four original feature maps
% ==========================================================

F_con = contrast(I);
F_chr = chrominance(I);
F_sal = saliency(I);
F_cc  = chromatic_contrast(I);


%% =========================================================
% Original method
% ==========================================================

if ablation_mode == 0

    W_old = ones(r,c,N) .* ...
            F_con .* F_chr .* F_sal .* F_cc;

    [~,max_idx] = max(W_old,[],3);

    W = zeros(size(W_old));

    linear_indices = sub2ind(size(W_old), ...
        repmat((1:r)',1,c), ...
        repmat(1:c,r,1), ...
        max_idx);

    W(linear_indices) = 1;


%% =========================================================
% New method
% ==========================================================

else

    eps_val = 1e-6;


    %% =====================================================
    % New Eq. (3): Feature normalization
    % ======================================================

    F_con_n = zeros(size(F_con));
    F_chr_n = zeros(size(F_chr));
    F_sal_n = zeros(size(F_sal));
    F_cc_n  = zeros(size(F_cc));


    for i = 1:N

        % Contrast
        temp = F_con(:,:,i);

        F_con_n(:,:,i) = ...
            (temp-min(temp(:))) ./ ...
            (max(temp(:))-min(temp(:))+eps_val);


        % Chrominance
        temp = F_chr(:,:,i);

        F_chr_n(:,:,i) = ...
            (temp-min(temp(:))) ./ ...
            (max(temp(:))-min(temp(:))+eps_val);


        % Saliency
        temp = F_sal(:,:,i);

        F_sal_n(:,:,i) = ...
            (temp-min(temp(:))) ./ ...
            (max(temp(:))-min(temp(:))+eps_val);


        % Chromatic contrast
        temp = F_cc(:,:,i);

        F_cc_n(:,:,i) = ...
            (temp-min(temp(:))) ./ ...
            (max(temp(:))-min(temp(:))+eps_val);

    end


    %% =====================================================
    % New Eq. (4): Adaptive feature weighting
    % ======================================================

    eta = 2;


    % Fixed equal weights
    if ablation_mode == 5

        W_con = ones(size(F_con_n))/4;
        W_chr = ones(size(F_chr_n))/4;
        W_sal = ones(size(F_sal_n))/4;
        W_cc  = ones(size(F_cc_n))/4;

    else

        E_con = exp(eta .* F_con_n);
        E_chr = exp(eta .* F_chr_n);
        E_sal = exp(eta .* F_sal_n);
        E_cc  = exp(eta .* F_cc_n);

        E_sum = E_con + E_chr + E_sal + E_cc + eps_val;

        W_con = E_con ./ E_sum;
        W_chr = E_chr ./ E_sum;
        W_sal = E_sal ./ E_sum;
        W_cc  = E_cc ./ E_sum;

    end


    %% =====================================================
    % Adaptive fusion score
    % ======================================================

    S = (F_con_n+eps_val).^W_con .* ...
        (F_chr_n+eps_val).^W_chr .* ...
        (F_sal_n+eps_val).^W_sal .* ...
        (F_cc_n+eps_val).^W_cc;


    %% =====================================================
    % New Eq. (5): Soft fusion
    % ======================================================

    if ablation_mode == 1 || ablation_mode == 2

        % Hard selection
        [~,max_idx] = max(S,[],3);

        W = zeros(size(S));

        linear_indices = sub2ind(size(S), ...
            repmat((1:r)',1,c), ...
            repmat(1:c,r,1), ...
            max_idx);

        W(linear_indices) = 1;

    else

        % Softmax fusion
        beta = 5;

        S_max = max(S,[],3);

        S_shift = S - repmat(S_max,[1 1 N]);

        E = exp(beta .* S_shift);

        W = E ./ (sum(E,3)+eps_val);

    end

end


%% =========================================================
% Eq. (6): Multi-scale reconstruction
% ==========================================================

pyr = gaussian_pyramid(zeros(r,c,3));

nlev = length(pyr);


for i = 1:N

    pyrW = gaussian_pyramid(W(:,:,i));

    pyrI = laplacian_pyramid(I(:,:,:,i));


    for l = 1:nlev

        w = repmat(pyrW{l},[1 1 3]);

        pyr{l} = pyr{l} + w .* pyrI{l};

    end

end


R = reconstruct_laplacian_pyramid(pyr);

end



% =========================================================
% Contrast feature
% ==========================================================

function C = contrast(I)

h = [0,1,0;
     1,-4,1;
     0,1,0];

N = size(I,4);

C = zeros(size(I,1),size(I,2),N);


for i = 1:N

    mono = rgb2gray(I(:,:,:,i));

    C(:,:,i) = abs(imfilter(mono,h,'replicate'));

end

end



% =========================================================
% Chrominance feature
% ==========================================================

function C = chrominance(I)

N = size(I,4);

C = zeros(size(I,1),size(I,2),N);


for i = 1:N

    R = I(:,:,1,i);
    G = I(:,:,2,i);
    B = I(:,:,3,i);

    mu = (R+G+B)/3;

    C(:,:,i) = sqrt(((R-mu).^2 + ...
                     (G-mu).^2 + ...
                     (B-mu).^2)/3);

end

end



% =========================================================
% Saliency feature
% ==========================================================

function C = saliency(I)

N = size(I,4);

C = zeros(size(I,1),size(I,2),N);


for i = 1:N

    C(:,:,i) = saliencyWeightmap(I(:,:,:,i));

end

end



% =========================================================
% Chromatic contrast feature
% ==========================================================

function C = chromatic_contrast(I)

alpha = 2;
phi = 250;

N = size(I,4);

C = zeros(size(I,1),size(I,2),N);


for i = 1:N

    [imhue,imsat,~] = rgb2hsv(I(:,:,:,i));

    I_gray = rgb2gray(I(:,:,:,i));

    C(:,:,i) = I_gray .* ...
        (1+cos(alpha*imhue+phi).*imsat);

end

end

